
           ##############################################################
           #    Alam, Md Ashad                                            #
           #    Helper function for robsut certer kernel matrix of RobKMR #        #
           ###############################################################
################################################################################
#                        Library Section                                       #
################################################################################
library(base)
library(MASS)
library(lattice)
library(Matrix)
library( nlme)
library(kernlab)
library(mvtnorm)
library(bigmemory)
###########################################

 ##############################################################################
 # Classical covariance operator  #
 #################################################
##############################################################################
# Function for  kernel CCA                                                    # 
 ###############################################################################
 
## gevd compute the generalized eigenvalue 
## decomposition for (A,B)
gevd<-function(A,B=diag(nrow(A)))
 {
  ss<-mfunc(B,function(x) ginvx(sqrt(x)))
  ev<-eigen(ss%*%A%*%ss)
  return(list(hfinv=ss,gvalues=ev$values,gvectors=ss%*%ev$vectors))
}


## mfunc is a helper to compute matrix functions
 mfunc<-function(A,fn=sqrt) {
  #A <- make.positive.definite(A)
   #A <- nearPD(A,conv.tol = 1e-7)
  e<-eigen(A); y<-e$vectors; v<-e$values
  return(tcrossprod(y%*%diag(fn(v)),y))
}


## ginvx is a helper to compute reciprocals
ginvx<-function(x) {ifelse(x==0,0,1/x)}

  ######################################
 MedianDist <- function(X)
 {
    n <- dim(X)[1]
    m  <- dim(X)[2]
    ab <- X%*%t(X)
    aa <- diag(ab)
    Dx <- matrix(aa,n,n)+ t(matrix(aa,n,n))- 2*ab
    Dx <- Dx -diag(diag(Dx)) 
    dx <- median(as.vector(Dx[Dx!=0]))
    s = sqrt(dx)
 return(s)
 }

######################################
# Center kernel matrix
 M_GK<-function(X)
  {
    n <- nrow(X)
    deuclid <- dist(X, method = "euclidean")
    aa <- c(as.matrix(deuclid))
    smed <- median(aa[aa!=0])
    #smed  <- MedianDist (X)
    d1 <- 1/(2*smed*smed)  #Greeton
    K <- kernelMatrix(X, kernel = rbfdot(d1))
    Id <- diag(1, nrow =n)
    Id1 <- matrix(1, nrow = n, ncol = n)
    H <- Id - Id1/n
    #CK <- H%*%K%*%H
    CK<- tcrossprod(H%*%K, H) # same as  CK <- H%*%K%*%H but faster
    CK <- (CK+t(CK))/2
    return( CK)
  }




#############################################################################
# Robust Kernel
##################################################
#Gausian kernel  with median of pairwis distiance
Huber_amedian<- function(x)
 {
    n<-length(x)
    a <-median(x)
    y <- rep(0, n)
    for (i in 1: n)
    {
      if( x[i] <= (a))
      {
      y[i] <-x[i]^2/2
      }
     else
    y[i] <- a*x[i]-a^2/2
   }
 return(y)
 }

####################################
# Objective funion
Obj_funciton<-function(x)
  {
   y<- Huber_amedian(x)
   obj<-mean(y)
  return(obj)
  }

#############################################
Huber_derivative_Ratio_median<- function(x) # derivative/ x of Huber funciton
  {
    n<-length(x)
    a <- median(x)
    y <- rep(0, n)
    for (i in 1: n)
    {
       if( x[i] <= (a))
       {
        y[i] <-1
        }
        else
        y[i] <- a/x[i]
    }
  return(y)

}
# Robust centering kernel matrix  n\timex n

 Robust_Cent_K <- function(K)  
  {
    n <-nrow(K)
    W <- rep(1/n, n)
     aa<- sqrt(abs(diag(K)-2*as.vector(crossprod(W,K))+ as.vector(crossprod(W,K%*%W))))
    for (k in 1:100)
    	{
       Obj.old<- Obj_funciton(aa)
        #error <- apply(aa, 2, norm_vec )
        HV <- Huber_derivative_Ratio_median(aa)
        THV <- sum(HV)
        W <-HV/THV
	  R_mean_E <-as.vector(crossprod(W,K))#as.vector(t(W)%*%K)
	  aa<- sqrt(abs(diag(K)-2*as.vector(crossprod(W,K))+ as.vector(crossprod(W,K%*%W))))
        Obj.new<- Obj_funciton(aa)
        Stop <- abs(Obj.old-Obj.new)/Obj.old
        if( Stop < 0.1^8)
          {
            break
          }
	     }
     ee<- rep(1, n)
    H <- diag(1, n)- as.vector(tcrossprod(ee,W))
    K.robust.M <-tcrossprod(H%*%K,H)
    K.robust.M <- (K.robust.M + t(K.robust.M))/2
    return(list(rckm=K.robust.M)) 
}



