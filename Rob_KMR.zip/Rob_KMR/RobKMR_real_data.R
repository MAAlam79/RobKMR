
           ###################################################################
           #    Alam, Md Ashad                                                #
           #    Main RobKMR function for real data analysis                   #
           ####################################################################

    
### ############################################################################
################################################################################
#                        Library Section                                       #
################################################################################
#setwd("/home/malam/kakon/NE1")
library(base)
library(MASS)
library(lattice)
library(Matrix)
library(nlme)
library(kernlab)
#library(varComp)
library(CCA)
#library(SPA3G)
library(dummies)
library(SKAT)
library(Hmisc)
library(gdata)
library(rsvd)
install.packages("SKAT")
################################################################################
 
### Identical by state (IBS) kernel

  IBS <- function(Z) ## Z is the full nxm SNP matrix
   {
	n <-  nrow(Z)
 K <- 1 - as.matrix(dist(Z, method = "manhattan") * 0.5/max(1, ncol(Z)))
	Id <- diag(1, nrow =n)
      Id1 <- matrix(1, nrow = n, ncol = n)
      H <- Id - Id1/n
      CK<- tcrossprod(H%*%K, H) # same as  CK <- H%*%K%*%H but faster
      CK <- (CK+t(CK))/2
    return(CK)
  }

 LK <- function(Z) ## Z is the full nxm SNP matrix
   {
	n <-  nrow(Z)
      K <- Z%*%t(Z)
	Id <- diag(1, nrow =n)
      Id1 <- matrix(1, nrow = n, ncol = n)
      H <- Id - Id1/n
      CK<- tcrossprod(H%*%K, H) # same as  CK <- H%*%K%*%H but faster
      CK <- (CK+t(CK))/2
    return(CK)
  }




 MedianDist <- function(X)
  {
   n <- dim(X)[1]
   ab <- X%*%t(X) 
   aa <- as.matrix(diag(ab))
   Dx <-matrix(rep(aa,each=n), ncol=n, byrow=TRUE) +  matrix(rep(aa,each=n),nrow=n) - 2*ab  
   Dx <- Dx-diag(diag(Dx))
   dx <- matrix(Dx, n*n,1)
   s <- sqrt(median(dx[dx!=0]))
  return (s)
 }

  


 M_GK <- function(X)
  {
    SGX <-  MedianDist(X)
    sx2  <- 2*SGX*SGX
    n <- dim(X)[1]
    ab <- X%*%t(X) 
    aa <- as.matrix(diag(ab))
    D <- matrix(rep(aa,each=n), ncol=n, byrow=TRUE) 
    xx <-pmax(D + t(D) - 2*ab,  mat.or.vec(n, n))
    K <- exp(-xx/sx2)  
    Id <- diag(1, nrow =n)
    Id1 <- matrix(1, nrow = n, ncol = n)
    H <- Id - Id1/n
    CK<- tcrossprod(H%*%K, H) # same as  CK <- H%*%K%*%H but faster
    CK <- (CK+t(CK))/2
    return(CK)
  }

######################## 
 ST <- function (M1, M2) 
  {
    nn <- nrow(M1)
    S <- c()
    for (itt in 1:nn) {
        S[itt] <- sum(M1[itt, ] * M2[, itt])
    }
    trace <- sum(S)
    return(trace)
  }
 
 MT <- function (M) 
     {
     return(sum(diag(M)))
      }

   
 MP <-function (MM) 
   {
    n <- nrow(MM)
    PMM <- MM - (matrix(1, n, 1) %*% apply(MM, 2, sum))/n
    return(PMM)
    }

 mgiv<-function (X, tol = sqrt(.Machine$double.eps)) 
  {
    if (length(dim(X)) > 2L || !(is.numeric(X) || is.complex(X))) 
        stop("'X' must be a numeric or complex matrix")
    if (!is.matrix(X)) 
        X <- as.matrix(X)
    Xsvd <- svd(X)
    if (is.complex(X)) 
        Xsvd$u <- Conj(Xsvd$u)
    Positive <- Xsvd$d > max(tol * Xsvd$d[1L], 0)
    if (all(Positive)) 
        Xsvd$v %*% (1/Xsvd$d * t(Xsvd$u))
    else if (!any(Positive)) 
        array(0, dim(X)[2L:1L])
    else Xsvd$v[, Positive, drop = FALSE] %*% ((1/Xsvd$d[Positive]) * 
        t(Xsvd$u[, Positive, drop = FALSE]))
 }


GKHOOVT <- function (Y, X,  K7)
  {
    n <- length(Y)
    be <- lm(Y~X)
    er <- be$residuals
    sig2 <- var(er)
    LSum<-matrix(0,n, n)
    for(i in 1:7)
    {
    LSum<- LSum + K7[[i]]
    }

    M <- LSum
    U <- t(er) %*% M %*% (er)/(2 * sig2)
    e <- MT(MP(M))/2
   {
   Ac111 <- c()
   Ac112 <- c()
   Ic111 <- c()
     for (i in 1:7)        # 7 =mc1+mc2+mc3 +mc4+mc5 =31, if m=5
       {
      for (j in i:7)
        if (i==j)
         {
           Ic111 <- c(Ic111, MT(MP(K7[[i]])))
           Ac111 <- c(Ac111, ST(MP(K7[[i]]), MP(K7[[j]])))
         }
      else
        Ac112 <- c(Ac112, ST(MP(K7[[i]]), MP(K7[[j]])))
     }
  }    #n (n+1)/2

    ode <- Ac112 
    die <-  Ac111
    Its <- Ic111
    COV <- matrix (0,7,7)
    COV[lower.tri( COV)] <- ode
    COV <- t(COV)
    COV[lower.tri( COV)] <- ode
    diag( COV) <-  die
    correct_COV <- (COV - Its %*% t(Its)/(n - 1))/2
    Itt <- sum(correct_COV)
    k <- Itt/(2 * e)
    v <- 2 * e^2/Itt
    pvalue <- pchisq(U/k, df = v, lower.tail = FALSE)
    object <- list(Score = U, p.value = pvalue, df = v, scale = k)
    class(object) <- "Score Test: tau1=tau2=tau3=0"
    return(object)
  }





 GKHOE <- function (Y, X, K7,  par)       # m1 SNP # Y is working vector(not binary)
  {
   n <- length(Y)
    p <- length(par)
    theta.new <- par
    theta.old <- rep(0, p)
    Vs <- array(0, c(n, n, 8))
    Vs[, , 1] <- diag(1, n)
   for (i in 1:7)
    {
    Vs[, , (i+1)] <- K7[[i]]
     }

     Sigma <- 0
    for (i in 1: p) {
        Sigma <- Sigma + theta.new[i] * Vs[, , i] # tau_3=0
    }
   #W <- solve(Sigma)
    W <- ginv(Sigma)
    R <- W - W %*% X %*% mgiv(t(X) %*% W %*% X) %*% t(X) %*%W
    kk <- g.old <- 0
    tt <- c()
    while (sum(abs(theta.new - theta.old)) > 1e-05 & kk < 100) {
           s <- theta.new - theta.old
            theta.old <- theta.new
            g <- c()
            for (i in 1:p) {
                g[i] <- -t(Y) %*% R %*% Vs[, , i] %*% R %*% Y +ST(R, Vs[, , i])
            }
            delta <- g - g.old
            g.old <- g
            if (kk == 0 | t(s) %*% delta <= 0) {
                AI <- matrix(0, p, p)
                for (i in 1:p) {
                  for (j in i:p) {
                    AI[i, j] <- t(Y) %*% R %*% Vs[,, i] %*% R %*% Vs[, , j] %*% R %*% Y
                  }
                }
                H_inv <- mgiv(AI)
            }
            else {
                rho <- c(1/(t(delta) %*% s))
                H_inv <- (diag(1, p) - (s %*% t(delta)) * rho) %*%H_inv %*% (diag(1, p) - rho * delta %*% t(s)) +rho * s                %*% t(s)
            }
        theta.new <- theta.old - H_inv %*% (g)
        alpha <- 0.5
        while (length(which(theta.new < 0)) > 0 & alpha > 1e-08) {
            theta.new <- theta.old - alpha * H_inv %*% (g)
            alpha <- alpha/2
        }
        theta.new[which(theta.new < 0)] <- 0
        Sigma.new <- 0
        for (i in 1:p) {
            Sigma.new <- Sigma.new + theta.new[i] * Vs[, , i]
        }
        #W.new <- solve(Sigma.new)
        W.new <- mgiv(Sigma.new)
        R <- W.new - W.new %*% X %*% mgiv(t(X) %*% W.new %*%X) %*% t(X) %*% W.new
        kk <- kk + 1
      cat("iteration = ",kk, "\n")
      }
    
    AVs <- matrix(0, n, n)
    for (i in 1:8)
     {
     AVs[i] <-list(R %*% Vs[, , i])
     }
     
    {
    Bc111 <- matrix(0, 8, 8)
       for (i in 1: 8)
       {
        for (j in 1: 8)
        {
         Bc111[i,j] <- ST(AVs[[i]], AVs[[j]])
        }
     }
  }
  eigen.sigma <- eigen(Sigma.new)
    lR <- -(sum(log(eigen.sigma$values)) + log(det(t(X) %*%W.new %*% X)) + t(Y) %*% R %*% Y)/2
     H <- Bc111/2
     beta <- solve(t(X) %*% W.new %*% X) %*% t(X) %*% W.new %*%Y
     object <- list(VCs = theta.new, fisher.info = H, Beta = beta,
     restricted.logLik = lR)
     return(object)
  }



 GKHOIT <- function (Y, X, K7,  par)
  {
    n <- dim(X)[1]
    p <- length(par)
   theta.new <- par
   theta.old <- rep(0, p)
   Vs <- array(0, c(n, n, 8))
    Vs[, , 1] <- diag(1, n)
   for (i in 1:7)
    {
    Vs[, , (i+1)] <- K7[[i]]
     }
     
    Sigma <- 0
    for (i in 1: p) {
        Sigma <- Sigma + theta.new[i] * Vs[, , i] # tau_3=0
    }
    #W <- solve(Sigma)
    W <- mgiv(Sigma)
    R <- W - W %*% X %*% mgiv(t(X) %*% W %*% X) %*% t(X) %*%W
    kk <- g.old <- 0
    tt <- c()
    while (sum(abs(theta.new - theta.old)) > 1e-05 & kk < 100) {
           s <- theta.new - theta.old
            theta.old <- theta.new
            g <- c()
            for (i in 1:p) {
                g[i] <- -t(Y) %*% R %*% Vs[, , i] %*% R %*% Y +ST(R, Vs[, , i])
            }
            delta <- g - g.old
            g.old <- g
            if (kk == 0 | t(s) %*% delta <= 0) {
                AI <- matrix(0, p, p)
                for (i in 1:p) {
                  for (j in i:p) {
                    AI[i, j] <- t(Y) %*% R %*% Vs[,, i] %*% R %*% Vs[, , j] %*% R %*% Y
                  }
                }
             #H_inv <-  solve(AI)
            H_inv <- mgiv(AI)
            }
            else {
                rho <- c(1/(t(delta) %*% s))
                H_inv <- (diag(1, p) - (s %*% t(delta)) * rho) %*%H_inv %*% (diag(1, p) - rho * delta %*% t(s)) +rho * s %*% t(s)
            }
        theta.new <- theta.old - H_inv %*% (g)
        alpha <- 0.5
        while (length(which(theta.new < 0)) > 0 & alpha > 1e-08) {
            theta.new <- theta.old - alpha * H_inv %*% (g)
            alpha <- alpha/2
        }
        theta.new[which(theta.new < 0)] <- 0
        Sigma.new <- 0
        for (i in 1:p) {
            Sigma.new <- Sigma.new + theta.new[i] * Vs[, , i]
        }
        #W.new <- solve(Sigma.new)
        W.new <- mgiv(Sigma.new)
        R <- W.new - W.new %*% X %*% mgiv(t(X) %*% W.new %*%X) %*% t(X) %*% W.new
        kk <- kk + 1
         #cat("iteration = ",kk, "\n")
      }
    AVs <- matrix(0, n,n)
    for (i in 1:8)
     {
     AVs[i] <-list(R %*% Vs[, , i])
     }
    {
    Bc111 <- matrix(0, 8, 8)
    Bc1118 <- c()
     for (i in 1:8)
      {
       for (j in 1:8)
       {
        Bc111[i,j] <- ST(AVs[[i]], AVs[[j]])
        }
     }
  }
   eigen.sigma <- eigen(Sigma.new)
        lR <- -(sum(log(eigen.sigma$values)) + log(det(t(X) %*%W.new %*% X)) + t(Y) %*% R %*% Y)/2
        W0 <- W.new
        beta <- mgiv(t(X) %*% W0 %*% X) %*% t(X) %*% W0 %*%Y
        Q <- t(Y - X %*% beta) %*% W0 %*% K7[[7]] %*% W0 %*% (Y -X %*% beta)/2
        e <- ST(R, K7[[7]])/2
        Its <- Bc111[-8,8]
        Iss <- Bc111[-8,-8]
        Itt <- (Bc111[8,8] - Its %*% mgiv(Iss) %*% Its)/2
        k <- Itt/e/2
        v = 2 * e^2/Itt
        pvalue <- pchisq(Q/k, df = v, lower.tail = F)
        object <- list(VCs = theta.new, fisher.info = Iss/2, Beta = beta, restricted.logLik = lR, Score = Q, df = v, scale = k, p.value = pvalue)
        class(object) <- "Score Test: tau3=0"
        return(object)
  }




###########
 GKHOIET <- function (Y, X, m1, m2, m3, cutoff=0.05)
  {
   n <- length(Y)
   K1 <- IBS(m1)
   K2 <- LK(m2)
   K3 <- LK(m3)
   K12 <- K1*K2
   K13 <- K1*K3
   K23 <- K2*K3
   K123 <- K1*K2*K3
   r <- 0.1*n
   rK1 <- rsvd(K1,r)[[2]] #Randomized Singular Value Decomposition (rsvd). # for the linear kernel
   rK2 <- rsvd(K2,r)[[2]]
   rK3 <- rsvd(K3,r)[[2]]
   rK12 <- rsvd(K12,r)[[2]]
   rK13 <- rsvd(K13,r)[[2]]
   rK23 <- rsvd(K23,r)[[2]]
   K7 <- list(K1, K2, K3, K12, K13, K23, K123)
   GKHOall <- GKHOOVT(Y, X, K7)

   if(GKHOall$p.value < cutoff)
      {
       setpara <- c(0, 1e-05, 1e-04, 0.001, 0.01) # shoult wirte (0 - 1)
        testI <- vector("list", length(setpara))
        for (i in 1:length(setpara))
           {
             par <- c(var(Y), rep(setpara[i], 6))
              testI[[i]] <- GKHOIT(Y, X, K7,  par)
            }
           testLR <- c()
            for (i in 1:length(testI))
             {
              testLR[i] <- testI[[i]]$restricted.logLik
              }
            HOI <- testI[[which.max(testLR)]]
            parall <- c(HOI$VCs, 0.01) # under nulmodel 0.01 =0
            allcomp <- GKHOE(Y, X, K7, parall)
            result <- list(Overall_test = GKHOall, HOInterstion = HOI, Allcomp = allcomp, RL = testLR)
        }
        else
        {
         V <- t(t(c(rep(9999999, 8))))
         allcomp <- list (V)
         names(allcomp) <- "VCs"
        object <- list(VCs = V, fisher.info =9999999, Beta = 9999999, restricted.logLik = 9999999, Score = 9999999, df = 9999999, scale = 9999999, p.value = "9999999")
       result <- list(Overall_test = GKHOall, HOInterstion = object, Allcomp = allcomp, RL = 9999999)
        }
    return(result)
 }
######################################################################
#### Example:  Data processing######################
###################################
    Y <- as.vector(Y)
    X <- as.matrix(Y)
########## You have to define  your data here
  M1 <- cbind(rnorm (100), rnorm (100))
  M2 <- cbind(rnorm (100), rnorm (100))
  M3  <- cbind(rnorm (100), rnorm (100))
  X <- cbind(rnorm (100), rnorm (100))
  Y <- rnorm (100)

####################################################### Data ####################
  M1 <- as.matrix(scale ( M1))
  M2 <- as.matrix(scale ( M2))
  M3 <- as.matrix(scale ( M3))

 d1 <- dim(M1)[2]
 d2 <-dim(M2)[2]
 d3 <-dim(M3)[2]


 ############################################################################
 ################################################# 
 #ptm <- proc.time() 
 #proc.time() - ptm
   G <-c()
       for(i in 1: d1) # ng number of gen
         {
           for(j in  1: d2) # nf
             {
              for(l in 1:d3)#nm
               {
               tryCatch({
              all <- GKHOIET(Y, X, as.matrix(M1[, i]), as.matrix(M2[,j]), as.matrix(M3[,l]),  cutoff=1)
                  }, error=function(e){})
               VCs <- t(all$Allcomp$VCs)
                    G <- rbind(G, c(c(i,j,l),  t(all$Allcomp$VCs), all$Overall_test$p.value,  all$HOInterstion$p.value))
              # colnames(G) <- c("i","j", "l", "Sigma","Tau1","Tau2","Tau3","Tau4","Tau5","Tau6", "Tau7","Overall Pv", "HOIpv")
              }  
            }
          }
   
#####################################


